=== Warda Marketplace ===
Contributors: warda
Tags: women, beauty, deals, products, ads.txt
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

متجر نسائي للعروض والمنتجات، الأقسام، الأسعار قبل/بعد الخصم، روابط المتاجر، أربع مساحات إعلانية وملف ads.txt.

== التثبيت ==
1. من لوحة WordPress اختاري إضافات ← أضف إضافة جديدة ← رفع إضافة.
2. ارفعي ملف warda-marketplace.zip وفعّليه.
3. أنشئي صفحة بعنوان «المتجر» وأضيفي الرمز [warda_marketplace].
4. من القائمة الجانبية «عروض وردة» أنشئي الأقسام وأضيفي عروض المنتجات.
5. لإعداد الإعلانات وSEO وads.txt افتحي «وردة · الإعدادات».

== رموز مختصرة ==
[warda_marketplace] يعرض المتجر والأقسام والإعلانات.
[warda_marketplace limit="8" columns="3"] يضبط عدد المنتجات والأعمدة.
[warda_marketplace show_categories="no" show_sidebar="no"] يخفي الأقسام والشريط الجانبي.
[warda_ad placement="header"] يعرض إعلانًا في موضع محدد (header, middle, sidebar, footer).

== المزايا ==
* Custom Post Type للعروض، وTaxonomy هرمية للأقسام.
* سعر حالي وسعر أصلي ونسبة التخفيض واسم المتجر ورابط المنتج الخارجي.
* صور المنتجات من الصورة البارزة في WordPress.
* إعلانات الهيدر والوسط والجانب والفوتر.
* رفع ملف ads.txt أو لصق سجلاته، وتقديمه على المسار /ads.txt.
* إعداد عنوان ووصف SEO للواجهة.
* بيانات المتجر محفوظة في قاعدة بيانات WordPress المعتادة.

== الأمان ==
يُشترط دور manage_options لإدارة الإعدادات والإعلانات، وتتحقق الإضافة من nonce وقدرة المستخدم عند حفظ المنتجات والإعدادات. روابط HTML وحقول الإدارة تُنقّى قبل الحفظ أو الإخراج.
