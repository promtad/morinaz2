<?php
/**
 * Plugin Name: Warda Marketplace
 * Plugin URI: https://example.com/warda-marketplace
 * Description: متجر وردة النسائي للعروض — منتجات وأقسام وأسعار مخفّضة وإعلانات في صفحة WordPress.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Warda
 * Text Domain: warda-marketplace
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WARDA_MARKETPLACE_VERSION', '1.0.0');
define('WARDA_MARKETPLACE_PATH', plugin_dir_path(__FILE__));
define('WARDA_MARKETPLACE_URL', plugin_dir_url(__FILE__));

function warda_marketplace_register_content() {
    $labels = array(
        'name'                  => 'عروض وردة',
        'singular_name'         => 'عرض',
        'menu_name'             => 'عروض وردة',
        'add_new'               => 'إضافة عرض',
        'add_new_item'          => 'إضافة عرض جديد',
        'edit_item'             => 'تعديل العرض',
        'new_item'              => 'عرض جديد',
        'view_item'             => 'مشاهدة العرض',
        'search_items'          => 'البحث في العروض',
        'not_found'             => 'لا توجد عروض بعد',
        'not_found_in_trash'    => 'لا توجد عروض في سلة المهملات',
        'all_items'             => 'كل العروض',
    );

    register_post_type('warda_deal', array(
        'labels'             => $labels,
        'public'             => true,
        'show_in_rest'       => true,
        'menu_icon'          => 'dashicons-heart',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt'),
        'has_archive'        => true,
        'rewrite'            => array('slug' => 'warda-deals'),
        'publicly_queryable' => true,
    ));

    register_taxonomy('warda_deal_category', array('warda_deal'), array(
        'labels' => array(
            'name'          => 'أقسام وردة',
            'singular_name' => 'قسم',
            'menu_name'     => 'الأقسام',
            'add_new_item'  => 'إضافة قسم جديد',
            'edit_item'     => 'تعديل القسم',
        ),
        'hierarchical'      => true,
        'show_in_rest'      => true,
        'show_admin_column' => true,
        'rewrite'           => array('slug' => 'warda-category'),
    ));
}
add_action('init', 'warda_marketplace_register_content');

function warda_marketplace_add_deal_box() {
    add_meta_box(
        'warda_deal_details',
        'تفاصيل العرض ورابط المتجر',
        'warda_marketplace_render_deal_box',
        'warda_deal',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'warda_marketplace_add_deal_box');

function warda_marketplace_render_deal_box($post) {
    wp_nonce_field('warda_save_deal', 'warda_deal_nonce');
    $price = get_post_meta($post->ID, '_warda_price', true);
    $old_price = get_post_meta($post->ID, '_warda_old_price', true);
    $merchant = get_post_meta($post->ID, '_warda_merchant', true);
    $product_url = get_post_meta($post->ID, '_warda_product_url', true);
    $featured = get_post_meta($post->ID, '_warda_featured', true);
    ?>
    <div class="warda-admin-deal-fields">
        <label><span>السعر الحالي (ر.س)</span><input type="number" min="0" step="1" name="warda_price" value="<?php echo esc_attr($price); ?>" /></label>
        <label><span>السعر قبل التخفيض (ر.س)</span><input type="number" min="0" step="1" name="warda_old_price" value="<?php echo esc_attr($old_price); ?>" /></label>
        <label><span>اسم المتجر</span><input type="text" name="warda_merchant" value="<?php echo esc_attr($merchant); ?>" /></label>
        <label class="warda-url-field"><span>رابط المنتج الخارجي (https://)</span><input type="url" name="warda_product_url" value="<?php echo esc_url($product_url); ?>" placeholder="https://store.example/product" /></label>
        <label class="warda-featured-field"><input type="checkbox" name="warda_featured" value="1" <?php checked($featured, '1'); ?> /><span>تمييز كاختيار وردة</span></label>
        <p class="description warda-full-row">اختاري صورة بارزة للعرض من صندوق «الصورة البارزة» لإظهارها في بطاقة المنتج.</p>
    </div>
    <?php
}

function warda_marketplace_save_deal($post_id) {
    if (!isset($_POST['warda_deal_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['warda_deal_nonce'])), 'warda_save_deal')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $price = isset($_POST['warda_price']) ? absint($_POST['warda_price']) : 0;
    $old_price = isset($_POST['warda_old_price']) ? absint($_POST['warda_old_price']) : 0;
    $merchant = isset($_POST['warda_merchant']) ? sanitize_text_field(wp_unslash($_POST['warda_merchant'])) : '';
    $product_url = isset($_POST['warda_product_url']) ? esc_url_raw(wp_unslash($_POST['warda_product_url'])) : '';
    update_post_meta($post_id, '_warda_price', $price);
    update_post_meta($post_id, '_warda_old_price', $old_price);
    update_post_meta($post_id, '_warda_merchant', $merchant);
    update_post_meta($post_id, '_warda_product_url', $product_url);
    update_post_meta($post_id, '_warda_featured', isset($_POST['warda_featured']) ? '1' : '0');
}
add_action('save_post_warda_deal', 'warda_marketplace_save_deal');

function warda_marketplace_admin_assets($hook) {
    if (strpos($hook, 'warda-marketplace') !== false || in_array($hook, array('post.php', 'post-new.php'), true)) {
        wp_enqueue_style('warda-marketplace-admin', WARDA_MARKETPLACE_URL . 'assets/warda-marketplace-admin.css', array(), WARDA_MARKETPLACE_VERSION);
    }
}
add_action('admin_enqueue_scripts', 'warda_marketplace_admin_assets');

function warda_marketplace_register_settings_page() {
    add_menu_page('إعدادات وردة', 'وردة · الإعدادات', 'manage_options', 'warda-marketplace', 'warda_marketplace_render_settings', 'dashicons-heart', 58);
}
add_action('admin_menu', 'warda_marketplace_register_settings_page');

function warda_marketplace_default_ads() {
    return array(
        'header'  => array('title' => '', 'image' => '', 'url' => ''),
        'middle'  => array('title' => '', 'image' => '', 'url' => ''),
        'sidebar' => array('title' => '', 'image' => '', 'url' => ''),
        'footer'  => array('title' => '', 'image' => '', 'url' => ''),
    );
}

function warda_marketplace_render_settings() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'guide';
    $tabs = array('guide' => 'ابدئي من هنا', 'ads' => 'إدارة الإعلانات', 'ads-txt' => 'ملف ads.txt', 'seo' => 'هوية الموقع وSEO');
    $ads = get_option('warda_marketplace_ads', warda_marketplace_default_ads());
    $site = get_option('warda_marketplace_site', array());
    $ads_txt = get_option('warda_marketplace_ads_txt', "# أضيفي سجلات المعلنين المعتمدين هنا، سطر لكل سجل\n");
    ?>
    <div class="wrap warda-admin-wrap">
        <div class="warda-admin-heading"><span class="warda-admin-logo">✿</span><div><span>WARDA · MARKETPLACE</span><h1>إعدادات وردة</h1><p>متجركِ النسائي، عروضكِ ومساحاتكِ الإعلانية في مكان واحد.</p></div></div>
        <nav class="nav-tab-wrapper warda-admin-tabs">
            <?php foreach ($tabs as $tab_id => $label) : ?>
                <a class="nav-tab <?php echo $tab === $tab_id ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=warda-marketplace&tab=' . $tab_id)); ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>

        <?php if ($tab === 'ads') : ?>
            <section class="warda-admin-panel">
                <h2>مساحات الإعلانات</h2>
                <p>أضيفي عنوانًا وصورة ورابطًا لكل إعلان. اتركي الحقول فارغة إذا لم ترغبي بعرض إعلان في ذلك الموضع.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="warda_save_ads" />
                    <?php wp_nonce_field('warda_save_ads'); ?>
                    <div class="warda-ad-position-grid">
                    <?php foreach (array('header' => 'الهيدر · أعلى الصفحة', 'middle' => 'وسط الصفحة', 'sidebar' => 'الجانب · بجوار المنتجات', 'footer' => 'الفوتر · أسفل المحتوى') as $placement => $label) :
                        $ad = isset($ads[$placement]) && is_array($ads[$placement]) ? $ads[$placement] : array(); ?>
                        <div class="warda-ad-position-card">
                            <span class="warda-admin-step"><?php echo esc_html(strtoupper($placement)); ?></span>
                            <h3><?php echo esc_html($label); ?></h3>
                            <label>عنوان الإعلان<input type="text" name="ads[<?php echo esc_attr($placement); ?>][title]" value="<?php echo esc_attr(isset($ad['title']) ? $ad['title'] : ''); ?>" /></label>
                            <label>رابط الصورة<input type="url" name="ads[<?php echo esc_attr($placement); ?>][image]" value="<?php echo esc_url(isset($ad['image']) ? $ad['image'] : ''); ?>" placeholder="https://..." /></label>
                            <label>الرابط عند النقر<input type="url" name="ads[<?php echo esc_attr($placement); ?>][url]" value="<?php echo esc_url(isset($ad['url']) ? $ad['url'] : ''); ?>" placeholder="https://yourstore.com" /></label>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <p class="submit"><button class="button button-primary button-large" type="submit">حفظ الإعلانات</button></p>
                </form>
            </section>
        <?php elseif ($tab === 'ads-txt') : ?>
            <section class="warda-admin-panel">
                <h2>ملف البائعين المعتمدين ads.txt</h2>
                <p>احفظي الملف ليصبح متاحًا على <code><?php echo esc_html(home_url('/ads.txt')); ?></code>. الملفات النصية فقط، حتى 100 كيلوبايت.</p>
                <form class="warda-ads-txt-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="warda_save_ads_txt" />
                    <?php wp_nonce_field('warda_save_ads_txt'); ?>
                    <label class="warda-file-label">رفع ملف .txt<input type="file" name="ads_txt_file" accept=".txt,text/plain" /></label>
                    <p class="description">إذا اخترتِ ملفًا، سيُستخدم محتواه بدل النص الموجود في المحرر.</p>
                    <label class="warda-txt-label">أو ألصقي/عدّلي محتوى الملف<textarea name="ads_txt_content" rows="13" dir="ltr" spellcheck="false"><?php echo esc_textarea($ads_txt); ?></textarea></label>
                    <p class="submit"><button class="button button-primary button-large" type="submit">حفظ ونشر ads.txt</button> <a class="button button-large" target="_blank" rel="noopener" href="<?php echo esc_url(home_url('/ads.txt')); ?>">معاينة الملف ↗</a></p>
                </form>
            </section>
        <?php elseif ($tab === 'seo') : ?>
            <section class="warda-admin-panel">
                <h2>هوية الموقع وتحسين محركات البحث</h2>
                <p>تُستخدم هذه البيانات في عنوان ووصف الصفحة الرئيسية. يمكنكِ ضبط رابط الموقع الأساسي من إعدادات WordPress.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="warda_save_site" />
                    <?php wp_nonce_field('warda_save_site'); ?>
                    <div class="warda-site-fields">
                        <label>اسم المتجر بالعربية<input type="text" name="site[name_ar]" value="<?php echo esc_attr(isset($site['name_ar']) ? $site['name_ar'] : get_bloginfo('name')); ?>" /></label>
                        <label>اسم المتجر بالإنجليزية<input type="text" name="site[name_en]" value="<?php echo esc_attr(isset($site['name_en']) ? $site['name_en'] : 'Warda'); ?>" /></label>
                        <label>عنوان SEO<input type="text" name="site[seo_title]" value="<?php echo esc_attr(isset($site['seo_title']) ? $site['seo_title'] : get_bloginfo('name')); ?>" /></label>
                        <label class="warda-full-field">وصف SEO<textarea name="site[seo_description]" rows="4"><?php echo esc_textarea(isset($site['seo_description']) ? $site['seo_description'] : get_bloginfo('description')); ?></textarea></label>
                    </div>
                    <p class="submit"><button class="button button-primary button-large" type="submit">حفظ هوية الموقع</button></p>
                </form>
            </section>
        <?php else : ?>
            <section class="warda-admin-panel warda-guide-panel">
                <span class="warda-guide-flower">✿</span><span class="warda-admin-step">جاهزة للبدء</span>
                <h2>أهلًا بكِ في وردة</h2>
                <p>أنشئي متجرًا نسائيًا مرتبًا للعروض والمنتجات باستخدام WordPress وقاعدة بيانات موقعكِ.</p>
                <div class="warda-guide-steps">
                    <article><span>01</span><div><strong>أضيفي الأقسام</strong><p>من «عروض وردة ← الأقسام» أضيفي المكياج والعناية والأزياء وغيرها.</p></div></article>
                    <article><span>02</span><div><strong>أضيفي عروض المنتجات</strong><p>اختاري «إضافة عرض»، وأضيفي السعر بعد التخفيض والسعر الأصلي ورابط المنتج والصورة.</p></div></article>
                    <article><span>03</span><div><strong>أظهري المتجر على الصفحة</strong><p>أنشئي صفحة WordPress جديدة، ثم أضيفي الرمز <code>[warda_marketplace]</code>.</p></div></article>
                    <article><span>04</span><div><strong>أديري الإعلانات وSEO</strong><p>من تبويبي «إدارة الإعلانات» و«ملف ads.txt» و«هوية الموقع وSEO».</p></div></article>
                </div>
                <div class="warda-shortcodes"><strong>الرموز القصيرة</strong><code>[warda_marketplace]</code><code>[warda_marketplace limit="8"]</code><code>[warda_ad placement="sidebar"]</code></div>
            </section>
        <?php endif; ?>
        <p class="warda-admin-footer">Warda Marketplace · إصدار <?php echo esc_html(WARDA_MARKETPLACE_VERSION); ?> · صُممت بحب</p>
    </div>
    <?php
}

function warda_marketplace_save_ads_handler() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('غير مصرح.', 'warda-marketplace'));
    }
    check_admin_referer('warda_save_ads');
    $raw = isset($_POST['ads']) && is_array($_POST['ads']) ? wp_unslash($_POST['ads']) : array();
    $clean = array();
    foreach (array('header', 'middle', 'sidebar', 'footer') as $placement) {
        $ad = isset($raw[$placement]) && is_array($raw[$placement]) ? $raw[$placement] : array();
        $clean[$placement] = array(
            'title' => sanitize_text_field(isset($ad['title']) ? $ad['title'] : ''),
            'image' => esc_url_raw(isset($ad['image']) ? $ad['image'] : ''),
            'url'   => esc_url_raw(isset($ad['url']) ? $ad['url'] : ''),
        );
    }
    update_option('warda_marketplace_ads', $clean, false);
    wp_safe_redirect(add_query_arg(array('page' => 'warda-marketplace', 'tab' => 'ads', 'updated' => '1'), admin_url('admin.php')));
    exit;
}
add_action('admin_post_warda_save_ads', 'warda_marketplace_save_ads_handler');

function warda_marketplace_save_site_handler() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('غير مصرح.', 'warda-marketplace'));
    }
    check_admin_referer('warda_save_site');
    $raw = isset($_POST['site']) && is_array($_POST['site']) ? wp_unslash($_POST['site']) : array();
    $site = array(
        'name_ar'         => sanitize_text_field(isset($raw['name_ar']) ? $raw['name_ar'] : ''),
        'name_en'         => sanitize_text_field(isset($raw['name_en']) ? $raw['name_en'] : ''),
        'seo_title'       => sanitize_text_field(isset($raw['seo_title']) ? $raw['seo_title'] : ''),
        'seo_description' => sanitize_textarea_field(isset($raw['seo_description']) ? $raw['seo_description'] : ''),
    );
    update_option('warda_marketplace_site', $site, false);
    wp_safe_redirect(add_query_arg(array('page' => 'warda-marketplace', 'tab' => 'seo', 'updated' => '1'), admin_url('admin.php')));
    exit;
}
add_action('admin_post_warda_save_site', 'warda_marketplace_save_site_handler');

function warda_marketplace_save_ads_txt_handler() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('غير مصرح.', 'warda-marketplace'));
    }
    check_admin_referer('warda_save_ads_txt');
    $content = isset($_POST['ads_txt_content']) ? sanitize_textarea_field(wp_unslash($_POST['ads_txt_content'])) : '';
    if (isset($_FILES['ads_txt_file']) && !empty($_FILES['ads_txt_file']['name'])) {
        $file = $_FILES['ads_txt_file'];
        $filename = sanitize_file_name($file['name']);
        if (strtolower(pathinfo($filename, PATHINFO_EXTENSION)) !== 'txt' || (int) $file['size'] > 102400 || (int) $file['error'] !== UPLOAD_ERR_OK) {
            wp_safe_redirect(add_query_arg(array('page' => 'warda-marketplace', 'tab' => 'ads-txt', 'error' => 'file'), admin_url('admin.php')));
            exit;
        }
        $mime = wp_check_filetype($filename);
        if ($mime['ext'] !== 'txt') {
            wp_safe_redirect(add_query_arg(array('page' => 'warda-marketplace', 'tab' => 'ads-txt', 'error' => 'file'), admin_url('admin.php')));
            exit;
        }
        $uploaded_content = file_get_contents($file['tmp_name']);
        if ($uploaded_content === false || strlen($uploaded_content) > 102400 || strpos($uploaded_content, "\0") !== false) {
            wp_safe_redirect(add_query_arg(array('page' => 'warda-marketplace', 'tab' => 'ads-txt', 'error' => 'file'), admin_url('admin.php')));
            exit;
        }
        $content = $uploaded_content;
    }
    update_option('warda_marketplace_ads_txt', $content, false);
    wp_safe_redirect(add_query_arg(array('page' => 'warda-marketplace', 'tab' => 'ads-txt', 'updated' => '1'), admin_url('admin.php')));
    exit;
}
add_action('admin_post_warda_save_ads_txt', 'warda_marketplace_save_ads_txt_handler');

function warda_marketplace_rewrite_rules() {
    add_rewrite_rule('^ads\.txt$', 'index.php?warda_ads_txt=1', 'top');
}
add_action('init', 'warda_marketplace_rewrite_rules', 1);
add_filter('query_vars', function ($vars) {
    $vars[] = 'warda_ads_txt';
    return $vars;
});

function warda_marketplace_serve_ads_txt() {
    if ((string) get_query_var('warda_ads_txt') !== '1') {
        return;
    }
    $content = get_option('warda_marketplace_ads_txt', "# Add authorized seller records here, one record per line.\n");
    nocache_headers();
    header('Content-Type: text/plain; charset=utf-8');
    echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain-text ads.txt records.
    exit;
}
add_action('template_redirect', 'warda_marketplace_serve_ads_txt');

function warda_marketplace_activate() {
    warda_marketplace_register_content();
    warda_marketplace_rewrite_rules();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'warda_marketplace_activate');
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

function warda_marketplace_front_assets() {
    wp_enqueue_style('warda-marketplace', WARDA_MARKETPLACE_URL . 'assets/warda-marketplace.css', array(), WARDA_MARKETPLACE_VERSION);
}

function warda_marketplace_render_ad($placement) {
    $allowed = array('header', 'middle', 'sidebar', 'footer');
    if (!in_array($placement, $allowed, true)) {
        return '';
    }
    $ads = get_option('warda_marketplace_ads', warda_marketplace_default_ads());
    $ad = isset($ads[$placement]) && is_array($ads[$placement]) ? $ads[$placement] : array();
    $title = isset($ad['title']) ? $ad['title'] : '';
    $image = isset($ad['image']) ? $ad['image'] : '';
    $url = isset($ad['url']) ? $ad['url'] : '';
    if (!$title && !$image) {
        return '';
    }
    $content = $image ? '<img src="' . esc_url($image) . '" alt="' . esc_attr($title) . '" loading="lazy">' : '<strong>' . esc_html($title) . '</strong>';
    $content .= '<span class="warda-ad-label">إعلان</span>';
    if ($url) {
        return '<a class="warda-ad warda-ad-' . esc_attr($placement) . '" href="' . esc_url($url) . '" target="_blank" rel="sponsored noopener noreferrer">' . $content . '</a>';
    }
    return '<div class="warda-ad warda-ad-' . esc_attr($placement) . '">' . $content . '</div>';
}

function warda_marketplace_ad_shortcode($atts) {
    $atts = shortcode_atts(array('placement' => 'header'), $atts, 'warda_ad');
    return warda_marketplace_render_ad(sanitize_key($atts['placement']));
}
add_shortcode('warda_ad', 'warda_marketplace_ad_shortcode');

function warda_marketplace_shortcode($atts) {
    warda_marketplace_front_assets();
    $atts = shortcode_atts(array('limit' => 12, 'columns' => 3, 'show_categories' => 'yes', 'show_sidebar' => 'yes'), $atts, 'warda_marketplace');
    $limit = max(1, min(48, absint($atts['limit'])));
    $columns = max(2, min(4, absint($atts['columns'])));
    $selected = isset($_GET['warda_category']) ? sanitize_title(wp_unslash($_GET['warda_category'])) : '';
    $query_args = array(
        'post_type'      => 'warda_deal',
        'post_status'    => 'publish',
        'posts_per_page' => $limit,
        'meta_key'       => '_warda_featured',
        'orderby'        => array('meta_value_num' => 'DESC', 'date' => 'DESC'),
    );
    if ($selected) {
        $query_args['tax_query'] = array(array('taxonomy' => 'warda_deal_category', 'field' => 'slug', 'terms' => $selected));
    }
    $query = new WP_Query($query_args);
    $terms = get_terms(array('taxonomy' => 'warda_deal_category', 'hide_empty' => true));
    ob_start();
    ?>
    <div class="warda-marketplace" dir="rtl">
        <?php echo warda_marketplace_render_ad('header'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        <header class="warda-marketplace-heading"><span class="warda-marketplace-eyebrow">اختيارات وردة · WARDA FINDS</span><h2><?php echo esc_html(get_option('warda_marketplace_site', array('name_ar' => 'وردة'))['name_ar'] ?? 'وردة'); ?> — عروض الجمال والأزياء</h2><p>اختيارات نسائية وعروض جميلة، ورابط مباشر إلى متجر المنتج.</p></header>
        <?php if ($atts['show_categories'] === 'yes' && !is_wp_error($terms) && $terms) : ?>
            <nav class="warda-categories" aria-label="أقسام وردة"><a class="<?php echo !$selected ? 'is-active' : ''; ?>" href="<?php echo esc_url(remove_query_arg('warda_category')); ?>">كل الاختيارات</a><?php foreach ($terms as $term) : ?><a class="<?php echo $selected === $term->slug ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('warda_category', $term->slug)); ?>"><?php echo esc_html($term->name); ?></a><?php endforeach; ?></nav>
        <?php endif; ?>
        <div class="warda-marketplace-layout">
            <div class="warda-marketplace-main"><div class="warda-products-grid" style="--warda-columns:<?php echo esc_attr($columns); ?>">
                <?php if ($query->have_posts()) : $index = 0; while ($query->have_posts()) : $query->the_post();
                    $post_id = get_the_ID();
                    $price = absint(get_post_meta($post_id, '_warda_price', true));
                    $old_price = absint(get_post_meta($post_id, '_warda_old_price', true));
                    $merchant = get_post_meta($post_id, '_warda_merchant', true);
                    $product_url = get_post_meta($post_id, '_warda_product_url', true);
                    $discount = ($old_price > 0 && $price < $old_price) ? round((($old_price - $price) / $old_price) * 100) : 0;
                    $out_url = $product_url ? $product_url : get_permalink();
                    ?>
                    <article class="warda-product-card">
                        <div class="warda-product-image"><a href="<?php echo esc_url($out_url); ?>" target="_blank" rel="sponsored noopener noreferrer"><?php if (has_post_thumbnail()) { the_post_thumbnail('large', array('loading' => 'lazy')); } else { ?><span class="warda-product-no-image">✿</span><?php } ?></a><?php if ($discount) : ?><span class="warda-discount">-<?php echo esc_html($discount); ?>٪</span><?php endif; ?><?php if (get_post_meta($post_id, '_warda_featured', true) === '1') : ?><span class="warda-featured">اختيار وردة</span><?php endif; ?></div>
                        <div class="warda-product-body"><span class="warda-product-merchant"><?php echo esc_html($merchant); ?></span><h3><a href="<?php echo esc_url($out_url); ?>" target="_blank" rel="sponsored noopener noreferrer"><?php echo esc_html(get_the_title()); ?></a></h3><p><?php echo esc_html(wp_trim_words(wp_strip_all_tags(get_the_excerpt() ?: get_the_content()), 17)); ?></p><div class="warda-product-prices"><?php if ($price) : ?><strong><?php echo esc_html(number_format_i18n($price)); ?> <small>ر.س</small></strong><?php endif; ?><?php if ($old_price > $price) : ?><del><?php echo esc_html(number_format_i18n($old_price)); ?> ر.س</del><?php endif; ?></div><a class="warda-product-link" href="<?php echo esc_url($out_url); ?>" target="_blank" rel="sponsored noopener noreferrer">شاهدي العرض <span>↗</span></a></div>
                    </article>
                    <?php $index++; if ($index === 4) { echo warda_marketplace_render_ad('middle'); } endwhile; wp_reset_postdata(); else : ?>
                    <div class="warda-empty"><span>✿</span><h3>لا توجد عروض في هذا القسم بعد</h3><p>أضيفي منتجات جديدة من لوحة التحكم لتظهر هنا.</p></div>
                <?php endif; ?>
            </div></div>
            <?php if ($atts['show_sidebar'] === 'yes') : ?><aside class="warda-marketplace-sidebar"><?php echo warda_marketplace_render_ad('sidebar'); ?><div class="warda-sidebar-note"><span>✿</span><strong>اختيارات وردة</strong><p>منتجات نسائية وعروض مختارة بعناية لتسهيل اكتشاف ما تحبين.</p></div></aside><?php endif; ?>
        </div>
        <?php echo warda_marketplace_render_ad('footer'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('warda_marketplace', 'warda_marketplace_shortcode');
add_shortcode('warda_deals', 'warda_marketplace_shortcode');

function warda_marketplace_document_title($title) {
    if (!is_front_page()) {
        return $title;
    }
    $site = get_option('warda_marketplace_site', array());
    if (!empty($site['seo_title'])) {
        return sanitize_text_field($site['seo_title']);
    }
    return $title;
}
add_filter('pre_get_document_title', 'warda_marketplace_document_title');

function warda_marketplace_meta_description() {
    if (!is_front_page() && !is_page()) {
        return;
    }
    $site = get_option('warda_marketplace_site', array());
    $description = isset($site['seo_description']) && $site['seo_description'] ? $site['seo_description'] : get_bloginfo('description');
    if ($description) {
        echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
    }
}
add_action('wp_head', 'warda_marketplace_meta_description', 2);

function warda_marketplace_admin_notice() {
    if (!isset($_GET['page']) || sanitize_key(wp_unslash($_GET['page'])) !== 'warda-marketplace') {
        return;
    }
    if (isset($_GET['updated'])) {
        echo '<div class="notice notice-success is-dismissible"><p>تم حفظ إعدادات وردة بنجاح.</p></div>';
    }
    if (isset($_GET['error']) && sanitize_key(wp_unslash($_GET['error'])) === 'file') {
        echo '<div class="notice notice-error is-dismissible"><p>الملف غير صالح. ارفعي ملف TXT صالحًا لا يتجاوز 100 كيلوبايت.</p></div>';
    }
}
add_action('admin_notices', 'warda_marketplace_admin_notice');
